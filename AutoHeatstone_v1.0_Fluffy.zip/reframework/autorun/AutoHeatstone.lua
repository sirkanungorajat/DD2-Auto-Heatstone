-- AutoHeatstone v1.0
-- Dragon's Dogma 2: Dark Arisen / REFramework
--
-- Grounded in ItemBelt 0.15.0 source supplied by the user:
--   Heatstone item ID: 806
--   Item count: ItemManager:getHaveNum(System.Int32, app.CharacterID)
--   Item use: ItemManager:useItem(item_id, player, player)
--   Status controller: player:get_StatusConditionCtrl()
--   Cold status reference: ID 24
--
-- Safety policy:
--   - only status ID 24 can trigger
--   - only item ID 806 can ever be used
--   - runtime item data must identify 806 exactly as "Heatstone"
--   - no hooks, no field writes, no raw-memory writes
--   - no add/delete/remove inventory calls
--   - one use per cold episode + cooldown
--   - any uncertainty => do nothing

local MOD_NAME = "AutoHeatstone"
local MOD_VERSION = "1.0"

local HEATSTONE_ID = 806
local COLD_STATUS_ID = 24

local CHECK_INTERVAL = 0.20
local REQUIRED_ACTIVE_SAMPLES = 3
local REQUIRED_CLEAR_SAMPLES = 3
local SECONDARY_COOLDOWN = 30.0

local state = {
    enabled = true,
    last_check = 0.0,
    active_samples = 0,
    clear_samples = 0,
    latched = false,
    last_use_time = -99999.0,

    cold_active = nil,
    runtime_item_name = nil,
    heatstone_count = nil,
    ready = false,
    last_action = "Waiting for game state...",
}

local function safe_call(fn)
    local ok, result = pcall(fn)
    if ok then return result end
    return nil
end

local function get_player()
    local cm = sdk.get_managed_singleton("app.CharacterManager")
    if not cm then return nil end
    return safe_call(function() return cm:get_ManualPlayer() end)
end

local function get_item_manager()
    return sdk.get_managed_singleton("app.ItemManager")
end

local function get_status_ctrl(player)
    if not player then return nil end
    return safe_call(function() return player:get_StatusConditionCtrl() end)
end

local function read_cold_status(player)
    local ctrl = get_status_ctrl(player)
    if not ctrl then return nil end
    return safe_call(function()
        return ctrl:IsStatusConditionActive(COLD_STATUS_ID, true)
    end)
end

local function get_runtime_heatstone_name(item_manager)
    if not item_manager then return nil end

    local dict = safe_call(function() return item_manager:get_field("_ItemDataDict") end)
    if not dict then return nil end

    local item_data = safe_call(function() return dict:get_Item(HEATSTONE_ID) end)
    if not item_data then return nil end

    local name = safe_call(function() return item_data:get_Name() end)
    if name == nil then return nil end
    return tostring(name)
end

local function runtime_heatstone_verified(item_manager)
    local name = get_runtime_heatstone_name(item_manager)
    state.runtime_item_name = name
    return name == "Heatstone"
end

local function get_heatstone_count(item_manager, player)
    if not item_manager or not player then return nil end

    local chara_id = safe_call(function() return player:get_CharaID() end)
    if chara_id == nil then return nil end

    local method = safe_call(function()
        return item_manager:get_type_definition():get_method("getHaveNum(System.Int32, app.CharacterID)")
    end)
    if not method then return nil end

    return safe_call(function()
        return method:call(item_manager, HEATSTONE_ID, chara_id)
    end)
end

local function get_use_item_method(item_manager)
    if not item_manager then return nil end
    return safe_call(function()
        return item_manager:get_type_definition():get_method("useItem")
    end)
end

local function refresh_readiness(player, item_manager)
    if not player or not item_manager then
        state.ready = false
        state.last_action = "INERT: player or ItemManager unavailable"
        return false
    end

    if not runtime_heatstone_verified(item_manager) then
        state.ready = false
        state.heatstone_count = nil
        state.last_action = "INERT: item 806 is not verified as exact 'Heatstone'"
        return false
    end

    local count = get_heatstone_count(item_manager, player)
    state.heatstone_count = count
    if count == nil then
        state.ready = false
        state.last_action = "INERT: could not read Heatstone count"
        return false
    end

    if not get_use_item_method(item_manager) then
        state.ready = false
        state.last_action = "INERT: ItemManager:useItem unavailable"
        return false
    end

    state.ready = true
    return true
end

local function use_one_heatstone(reason)
    local player = get_player()
    local item_manager = get_item_manager()

    if not refresh_readiness(player, item_manager) then
        return false
    end

    if not state.heatstone_count or state.heatstone_count <= 0 then
        state.last_action = "BLOCKED: no Heatstones in inventory"
        return false
    end

    -- Re-verify identity immediately before the only state-changing call.
    if not runtime_heatstone_verified(item_manager) then
        state.last_action = "BLOCKED: item 806 failed exact Heatstone verification before use"
        return false
    end

    local use_item = get_use_item_method(item_manager)
    if not use_item then
        state.last_action = "BLOCKED: useItem unavailable before use"
        return false
    end

    local ok = pcall(function()
        -- Exact call used by ItemBelt 0.15.0 for buffers/consumables.
        use_item:call(item_manager, HEATSTONE_ID, player, player)
    end)

    if not ok then
        state.last_action = "ERROR: native Heatstone use call failed"
        return false
    end

    state.last_use_time = os.clock()
    state.last_action = "Used one verified Heatstone (" .. tostring(reason) .. ")"
    state.heatstone_count = get_heatstone_count(item_manager, player)
    return true
end

re.on_frame(function()
    if not state.enabled then return end

    local now = os.clock()
    if now - state.last_check < CHECK_INTERVAL then return end
    state.last_check = now

    local player = get_player()
    local item_manager = get_item_manager()

    if not refresh_readiness(player, item_manager) then
        state.cold_active = nil
        state.active_samples = 0
        return
    end

    local cold = read_cold_status(player)
    state.cold_active = cold

    if cold == nil then
        state.active_samples = 0
        state.clear_samples = 0
        state.last_action = "INERT: could not read status ID 24"
        return
    end

    if cold == true then
        state.clear_samples = 0

        if not state.latched then
            state.active_samples = state.active_samples + 1

            if state.active_samples >= REQUIRED_ACTIVE_SAMPLES then
                if now - state.last_use_time >= SECONDARY_COOLDOWN then
                    if use_one_heatstone("Chilled/Cold status 24 active") then
                        state.latched = true
                    end
                else
                    state.last_action = "Cold active; cooldown prevents duplicate use"
                end
                state.active_samples = REQUIRED_ACTIVE_SAMPLES
            end
        end
    else
        state.active_samples = 0
        state.clear_samples = state.clear_samples + 1

        if state.latched and state.clear_samples >= REQUIRED_CLEAR_SAMPLES then
            state.latched = false
            state.last_action = "Re-armed; cold status cleared"
        elseif not state.latched then
            state.last_action = "Ready; waiting for Chilled/Cold status"
        end
    end
end)

re.on_draw_ui(function()
    if not imgui.collapsing_header(MOD_NAME .. " v" .. MOD_VERSION) then return end

    local changed
    changed, state.enabled = imgui.checkbox("Enabled", state.enabled)

    imgui.text("Trigger: StatusCondition ID 24 only")
    imgui.text("Cold/Chilled status active: " .. tostring(state.cold_active))
    imgui.text("Heatstone ID: 806")
    imgui.text("Runtime item name: " .. tostring(state.runtime_item_name or "<unread>"))
    imgui.text("Heatstones in inventory: " .. tostring(state.heatstone_count or "<unread>"))
    imgui.text("Ready: " .. tostring(state.ready))
    imgui.text("Latched: " .. tostring(state.latched))
    imgui.text("Status: " .. tostring(state.last_action))

    imgui.text("Safety: if item 806 is not exactly 'Heatstone', nothing is consumed.")
end)

log.info("[AutoHeatstone] Loaded v" .. MOD_VERSION .. " | Heatstone=806 | Cold status=24")
