AutoHeatstone v1.0
==================

Purpose
-------
Automatically use one Heatstone when the Arisen's Dark Arisen cold/Chilled status activates.

Grounded runtime paths
----------------------
From ItemBelt 0.15.0 source supplied by the user:
- Heatstone item ID = 806
- item count = getHaveNum(System.Int32, app.CharacterID)
- consumable use = ItemManager:useItem(item_id, player, player)
- status controller = player:get_StatusConditionCtrl()
- Cold reference = status ID 24

Safety
------
- only status ID 24 can trigger the mod
- only item ID 806 can ever be used
- immediately before use, runtime item data must identify 806 exactly as "Heatstone"
- no sdk.hook
- no set_field
- no raw memory writes
- no deleteItem/removeItem/addItem/gainItem calls
- one-shot latch prevents repeat consumption during the same cold episode
- 30-second secondary cooldown
- any failed verification => mod does nothing

Installation
------------
Import the ZIP into Fluffy Mod Manager and enable it.
The installed file is:
reframework/autorun/AutoHeatstone.lua

Disable all older AutoHeatstone automation versions first.

In-game toggle/status
---------------------
REFramework -> Script Generated UI -> AutoHeatstone v1.0
The Enabled checkbox toggles the automation live.
